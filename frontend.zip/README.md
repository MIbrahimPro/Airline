<h1>Airline Reservation System</h1>

Created using React

<h2>To run app</h2>

open folder in terminal

run command,

1. Install Dependencies
``` 
npm install
```

2. Start Local server
```
npm start
```

3. If browser doesnt open automatically, open any browser and visit 
```
http://localhost:3000/
```